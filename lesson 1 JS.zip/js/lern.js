function startWork(){



    
    

};

function eve(){

    for(i=0;i<100;i++){

        let a = document.getElementById("lov");
    let b = document.body;
    b.style.backgroundColor="Blue";
    a.style.backgroundColor ='pink';
    a.innerHTML = 'Я тебя люблю!!'
    let c =document.createElement('H1');
    b.appendChild(c);
    c.innerHTML='Я люблю тебя !';
    c.style.fontSize= "100px";


    };

   

};




window.onload = function(){
    
    console.log('Страница загружена');

    startWork();

};


 
 